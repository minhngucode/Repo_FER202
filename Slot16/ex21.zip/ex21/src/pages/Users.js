import React from "react";
import UserList from "../components/UserList";

const Users = () => {
  return <UserList />;
};

export default Users;
